import { open } from "node:fs/promises";

export async function writeFileExclusive(filePath, data, { mode = 0o600 } = {}) {
  const fh = await open(filePath, "wx", mode);
  try {
    await fh.writeFile(data);
  } finally {
    await fh.close();
  }
}
