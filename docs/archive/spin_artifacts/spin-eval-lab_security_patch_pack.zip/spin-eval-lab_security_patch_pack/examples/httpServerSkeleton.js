import http from "node:http";
import { readFile } from "node:fs/promises";
import path from "node:path";

import { enforceStrictMode } from "../security/strictMode.js";
import { applySecurityHeaders } from "../security/headers.js";
import { readJson } from "../security/readJson.js";
import { createRateLimiter } from "../security/rateLimit.js";
import { createJobQueue } from "../security/jobQueue.js";
import { createRunDir, writeJsonSigned } from "../security/artifactStore.js";
import { validateRunRequest } from "./validateRunRequest.js";
import { serveStatic } from "../security/staticServe.js";

const STRICT = process.env.STRICT_MODE === "1";
const BIND_HOST = process.env.BIND_HOST || "127.0.0.1";
const PORT = Number(process.env.PORT || 8787);
const BODY_MAX = Number(process.env.BODY_MAX_BYTES || 65536);
const ARTIFACT_DIR = process.env.ARTIFACT_DIR || "./artifacts";

enforceStrictMode({ strict: STRICT, bindHost: BIND_HOST, bodyMaxBytes: BODY_MAX });

const limiter = createRateLimiter({ capacity: 60, refillPerSec: 1 });
const queue = createJobQueue({ maxConcurrent: 2 });
const serveUI = serveStatic({ baseDir: path.join(process.cwd(), "ui-dist") });

async function loadPrivateKey() {
  const p = process.env.PRIVATE_KEY_PATH || "./keys/private.pem";
  return readFile(p, "utf8");
}

function getIp(req) {
  // if you trust x-forwarded-for, parse it here; otherwise use socket address
  return req.socket.remoteAddress || "unknown";
}

function send(res, code, obj) {
  const body = JSON.stringify(obj, null, 2) + "\n";
  res.writeHead(code, { "Content-Type": "application/json; charset=utf-8" });
  res.end(body);
}

const server = http.createServer(async (req, res) => {
  applySecurityHeaders(res);

  const ip = getIp(req);
  if (!limiter.take(ip, 1)) return send(res, 429, { error: "rate_limited" });

  // serve static UI first (optional)
  if (req.method === "GET") {
    const handled = serveUI(req, res);
    if (handled) return;
  }

  try {
    if (req.method === "POST" && req.url === "/api/run") {
      const body = await readJson(req, { maxBytes: BODY_MAX });
      const { flowId, config } = validateRunRequest(body);

      const result = await queue.enqueue(async () => {
        const runId = `${Date.now()}_${Math.random().toString(16).slice(2)}`;
        const runDir = await createRunDir(ARTIFACT_DIR, runId);
        const privatePem = await loadPrivateKey();

        const meta = { runId, flowId, config, createdAt: new Date().toISOString() };
        await writeJsonSigned(runDir, "meta", meta, privatePem);
        // TODO: run the actual runner + write results signed

        return { runId };
      });

      return send(res, 200, result);
    }

    return send(res, 404, { error: "not_found" });
  } catch (e) {
    return send(res, 400, { error: e.message });
  }
});

server.listen(PORT, BIND_HOST, () => {
  console.log(`Server listening on http://${BIND_HOST}:${PORT} (STRICT_MODE=${STRICT ? "1" : "0"})`);
});
