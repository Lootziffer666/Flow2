import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";

test("run_benchmarks produces complete status (private)", () => {
  const root = process.cwd();
  const artifactPath = path.join(root, "private/_inbox/artifact.json");
  assert.ok(fs.existsSync(artifactPath), "missing example artifact; run install script");

  const env = { ...process.env, FLOW_CMD: `${process.execPath} flow/flow_cli.mjs` };
  const p = spawnSync(process.execPath, ["scripts/run_benchmarks.mjs", "--artifact", "private/_inbox/artifact.json", "--out", "private/runs"], {
    encoding: "utf-8",
    env,
    stdio: "inherit"
  });
  assert.equal(p.status, 0);

  const art = JSON.parse(fs.readFileSync(artifactPath, "utf-8"));
  const statusPath = path.join(root, "private/runs", art.artifact_id, "run_status.json");
  assert.ok(fs.existsSync(statusPath));
  const status = JSON.parse(fs.readFileSync(statusPath, "utf-8"));
  assert.equal(status.status, "complete");
});
