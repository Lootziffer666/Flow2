export function enforceStrictMode({
  strict,
  bindHost,
  bodyMaxBytes,
} = {}) {
  if (!strict) return;

  if (bindHost !== "127.0.0.1" && bindHost !== "localhost") {
    throw new Error(`STRICT_MODE: bindHost must be localhost (got: ${bindHost})`);
  }

  if (!Number.isFinite(bodyMaxBytes) || bodyMaxBytes <= 0 || bodyMaxBytes > 1024 * 1024) {
    throw new Error(`STRICT_MODE: bodyMaxBytes invalid (got: ${bodyMaxBytes})`);
  }
}
