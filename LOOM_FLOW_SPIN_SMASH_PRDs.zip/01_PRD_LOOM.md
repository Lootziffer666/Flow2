# PRD — LOOM

## Die zugrunde liegende Sprach- und Strukturengine für FLOW, SPIN und SMASH

## TL;DR

**LOOM** ist die grundlegende Engine des Ökosystems.
LOOM schreibt nicht, bewertet nicht im literarischen Sinn und ersetzt keine Autorenschaft. LOOM ist die **strukturelle Verarbeitungs- und Diagnoseschicht**, die sprachliche Einheiten zerlegt, Relationen sichtbar macht, Zustände klassifiziert und daraus produktabhängige Signale für andere Werkzeuge ableitet.

Wenn FLOW Texte repariert, SPIN Ausdruck sichtbar macht und SMASH Blockaden unterbricht, dann ist LOOM die Ebene, die erkennt, **womit** das jeweilige System es überhaupt zu tun hat.

LOOM ist damit nicht einfach „Backend“, sondern die gemeinsame **Interpretationslogik** des gesamten Produktuniversums.

---

## Problem Statement

Die meisten Sprachtools sind entweder:

* reine Oberflächenwerkzeuge,
* generative Systeme ohne transparente Zwischenlogik,
* oder eng begrenzte Einzeltools ohne gemeinsame strukturelle Basis.

Das erzeugt ein Kernproblem:
Jedes Produkt löst lokal einen Ausschnitt, aber es gibt **keine konsistente Sprachebene**, auf der Text, Reibung, Struktur, Konflikt, Schreibzustand und Überarbeitung zusammenhängend beschrieben werden können.

Ohne diese gemeinsame Grundlage entstehen:

* inkonsistente Diagnosen,
* unverbundene Features,
* schwer erklärbare Produktentscheidungen,
* und langfristig ein zerfaserter Werkzeugpark statt eines echten Systems.

LOOM schließt genau diese Lücke.

---

## Produktziel

LOOM soll eine gemeinsame, deterministische und erweiterbare Engine bereitstellen, die:

* Text in strukturell sinnvolle Einheiten zerlegt
* sprachliche Muster klassifiziert
* Reibung, Belastung, Konflikt, Dichte und Zustand als getrennte Signale modelliert
* produktübergreifend nutzbare Diagnosen erzeugt
* keine generative Ersetzung, sondern interpretierbare Strukturarbeit ermöglicht

---

## Business Goals

* Gemeinsame Grundlage für alle Produkte im Ökosystem schaffen
* Technische und konzeptionelle Doppelarbeit vermeiden
* Eine klare proprietäre Produktlogik aufbauen, die nicht nur UI, sondern Denkmodell ist
* Erweiterbarkeit sicherstellen: von Textnormalisierung über Strukturdiagnose bis Zustandsintervention
* Das System langfristig als **eigenständige Sprachinfrastruktur** positionieren, nicht als lose Tool-Sammlung

---

## User Goals

LOOM hat keine direkte Endnutzeroberfläche im klassischen Sinn, aber indirekt dient es vier Nutzerzielen:

* Nutzer:innen sollen konsistente Signale über alle Tools hinweg erleben
* Hinweise sollen erklärbar statt magisch wirken
* unterschiedliche Probleme sollen als unterschiedliche Probleme erkannt werden
* Produkte sollen nicht widersprüchlich handeln, sondern auf derselben Grundlogik aufbauen

---

## Non-Goals

LOOM ist nicht:

* ein generatives Sprachmodell
* ein Ghostwriter
* ein universelles NLP-System für beliebige Aufgaben
* ein Black-Box-Scoring-Modell
* ein Produkt mit Selbstzweck
* eine reine Datenhaltungsschicht
* ein Marketingname ohne technische Substanz

---

## Kernthese

**Ohne LOOM wären FLOW, SPIN und SMASH drei getrennte Werkzeuge.
Mit LOOM werden sie zu drei Ausdrucksformen derselben sprachlichen Intelligenz.**

---

## Produktprinzipien

### 1. Struktur vor Oberfläche

LOOM interessiert sich nicht zuerst für hübschen Output, sondern für belastbare Zerlegung, Relation und Signalbildung.

### 2. Diagnose vor Ersetzung

LOOM soll Probleme kenntlich machen, nicht Texte übernehmen.

### 3. Trennung statt Einheits-Score

Phonetische Reibung, strukturelle Leselast, Normalisierungsbedarf, Blockadesignale und logische Konflikte bleiben getrennte Ebenen.

### 4. Determinismus, wo möglich

Gerade im Kernsystem ist Nachvollziehbarkeit wichtiger als „Smartness“.

### 5. Erweiterbarkeit ohne Identitätsverlust

LOOM muss neue Signale und Module aufnehmen können, ohne in einen beliebigen Feature-Sumpf zu kippen.

---

## Funktionsbild von LOOM

LOOM ist die Ebene, die aus sprachlichem Material eine bearbeitbare Struktur macht.

### LOOM soll können:

* Satz- und Segmentzerlegung
* Chunking in bedeutungstragende Einheiten
* Erkennung lokaler Relationen
* Diagnose von Stabilität, Mehrkernigkeit, Konflikt, Dichte oder Bruch
* Ableitung produktrelevanter Signale für FLOW, SPIN und SMASH
* Re-Rendering als strukturell nachvollziehbaren Schritt, ohne Textproduktion zu übernehmen
* Übergabe von Signalen an darüberliegende Produktschichten

---

## Rolle im Ökosystem

### LOOM → FLOW

LOOM liefert Struktur- und Kontextverständnis, damit FLOW Reparatur nicht blind als bloße Wortersetzung ausführt.

### LOOM → SPIN

LOOM liefert die eigentliche strukturelle Grammatik, Chunk-Logik, Diagnose und Re-Render-Basis, auf der SPIN als Arbeitsoberfläche operiert.

### LOOM → SMASH

LOOM liefert Signale darüber, ob das Problem eher in Struktur, Entscheidung, Festhängen, Satzzustand oder textinternen Konflikten liegt — und macht Interventionen gezielter.

---

## User Experience — indirekt, aber zentral

Nutzer:innen „sehen“ LOOM meist nicht als eigenes Produkt. Sie erleben LOOM über Eigenschaften wie:

* Konsistenz
* Präzision
* Nachvollziehbarkeit
* geringe Willkür
* sinnvoll getrennte Signale
* gleiche Produktphilosophie über alle Tools hinweg

Das ist wichtig:
LOOM ist nicht unsichtbar im Wert, nur unsichtbar in der UI.

---

## Kernkomponenten

### 1. Chunking Engine

Zerlegt Texte in funktionale Einheiten wie Subjekt, Handlung, Zustand, Relation, Objekt, Modifikator.

### 2. Structural State Layer

Klassifiziert strukturelle Zustände:

* stabil
* mehrkernig
* konfliktär
* überladen
* fragmentiert
* linear tragfähig

### 3. Re-Render Layer

Erlaubt strukturelle Neuordnung als prüfbaren Schritt, ohne generative Ausformulierung zu übernehmen.

### 4. Signal Layer

Leitet produktspezifische Signale ab:

* Reparaturbedarf für FLOW
* Ausdrucks- und Lastsignale für SPIN
* Blockade- oder Festhängesignale für SMASH

### 5. Explainability Layer

Jede Diagnose sollte auf interne Strukturen oder Regeln zurückführbar sein.

---

## Success Metrics

* Konsistenz produktübergreifender Diagnosen
* Erklärbarkeit von Signalen
* Wiederverwendbarkeit derselben Kernlogik in mehreren Produkten
* Reduktion redundanter Regeln in einzelnen Tools
* Produktteams können Features auf LOOM aufbauen statt parallel neue Logiken zu erfinden

---

## Technical Considerations

* modulare Engine-Architektur
* deterministische Kernpfade
* klar trennbare Signalklassen
* API oder interne Contracts für FLOW / SPIN / SMASH
* Versionierung von Diagnosen und States
* später erweiterbar um schwächere probabilistische Hilfssignale, aber nie als Black Box im Kern

---

## Milestones & Sequencing

### Milestone 1

Chunking- und Strukturdiagnose für einfache bis mittlere Satzformen

### Milestone 2

Stabilitäts-, Konflikt- und Dichtezustände sauber modellieren

### Milestone 3

Signal-API für FLOW und SPIN

### Milestone 4

Blockade-relevante Zustandsmuster für SMASH anbinden

### Milestone 5

Erklär- und Benchmark-Oberfläche für Engine-Qualität

---

## Narrative

LOOM ist der Webstuhl des gesamten Systems. Ohne ihn bleiben die Produkte Einzellösungen: eins repariert, eins analysiert, eins entblockt. Mit LOOM bekommen sie eine gemeinsame grammatische, strukturelle und zustandsbezogene Basis. Das macht das Ökosystem nicht nur technisch sauberer, sondern inhaltlich glaubwürdiger. Es entsteht keine lose Familie von Schreibtools, sondern eine zusammenhängende Sprachumgebung, in der jede Schicht eine andere Aufgabe erfüllt, aber alle dieselbe Sprache sprechen.
