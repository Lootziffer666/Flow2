import { createHash } from "node:crypto";

export function sha256Hex(strOrBuf) {
  return createHash("sha256").update(strOrBuf).digest("hex");
}
