# PRD — FLOW

## Reibungskiller am Ursprung / deterministische Normalisierungsschicht

## TL;DR

**FLOW** ist die frühe Reparatur- und Normalisierungsschicht des Ökosystems.
FLOW kümmert sich um den Bereich, in dem Schreiben oft schon vor Stil, Struktur oder Ausdruck scheitert: **orthografische, formale und oberflächennahe Reibung**.

FLOW ist kein Ghostwriter und kein freier Rewriter. FLOW repariert **begrenzt, nachvollziehbar und deterministisch**. Die bestehende Engine-Realität ist hier bereits deutlich: rule-based pipeline, grammar/context layer, benchmark tooling und native Windows shell.

Wichtig: FLOW ist **nicht die Hauptengine**, sondern eine **abgeleitete Normalisierungsschicht**, die auf der zugrunde liegenden Logik des Gesamtsystems aufsetzt.

---

## Problem Statement

Viele Texte scheitern schon auf der untersten Ebene:

* orthografische Fehler
* LRS-nahe Fehlermuster
* Oberflächenrauschen
* fehlerhafte Schreibbilder
* unnötige Friktion beim Tippen und Lesen

Diese Reibung ist nicht nur kosmetisch. Sie beschädigt:

* Schreibfluss
* Selbstvertrauen
* Lesbarkeit
* Anschlussfähigkeit an weitere Bearbeitung

Gleichzeitig sind viele bestehende Korrekturtools zu breit, zu intransparent oder zu generativ. Sie reparieren nicht nur Oberfläche, sondern greifen in Ton, Stil oder Formulierung ein.

FLOW adressiert deshalb nicht „Textverbesserung allgemein“, sondern **bounded text repair**.

---

## Produktziel

FLOW soll Texte an der Oberfläche so weit stabilisieren, dass Nutzer:innen ohne unnötige Reibung weiterschreiben, prüfen und überarbeiten können.

FLOW soll:

* zuverlässig reparieren
* nicht umschreiben
* transparent bleiben
* lokal und kontrollierbar sein
* für LRS-nahe Fehlermuster besonders stark sein
* als vorgeschaltete Schicht den Weg zu SPIN und SMASH erleichtern

---

## Business Goals

* Eine starke, glaubwürdige Unterkante des Produktökosystems schaffen
* Ein reales Alltagsproblem mit klarer Nutzbarkeit lösen
* FLOW als stabilen Einstieg in das System nutzbar machen
* Eine differenzierte Alternative zu cloudbasierten, intransparenten Korrekturtools aufbauen
* Benchmark- und Evaluationskultur zum Kernbestandteil machen statt „smart sounding edits“

---

## User Goals

* Ich will, dass unnötige Schreibfehler mich nicht dauernd ausbremsen
* Ich will Hilfe, ohne dass mir mein Text weggenommen wird
* Ich will nachvollziehen können, was korrigiert wurde und warum
* Ich will lokale, datenschutzfreundliche Verarbeitung
* Ich will auch bei fehlerhaftem Rohtext anschlussfähig bleiben

---

## Non-Goals

FLOW ist nicht:

* ein freier Paraphrasier
* ein Stiloptimierer
* ein AI-Rewriter
* ein Tool für ästhetische Ausdrucksverbesserung
* eine Strukturdiagnose-Umgebung
* ein Schreibtrainer
* ein System, das semantisch offen „bessere“ Formulierungen generiert

---

## Produktprinzipien

### 1. Deterministisch statt magisch

Gleiche Eingabe, gleiche Ausgabe.

### 2. Begrenzt statt übergriffig

FLOW repariert, aber übernimmt keine Textverantwortung.

### 3. Lokal statt Cloud-Zwang

Datenschutz und Kontrolle sind Teil des Produkts.

### 4. Messbar statt gefühlt

Änderungen sollen benchmarkbar und prüfbar sein.

### 5. Reibung früh senken

FLOW arbeitet am Ursprung vieler Schreibabbrüche: Oberfläche, Lesbarkeit, formale Hürden.

---

## Produktlogik

FLOW ist die erste praktische Schicht im System.

### Im Gesamtbild:

* **LOOM** interpretiert Struktur und Signale
* **FLOW** reduziert Oberflächenreibung
* **SPIN** macht Ausdruck und Struktur sichtbar
* **SMASH** hilft, wenn Schreiben trotz allem blockiert

FLOW muss daher nicht „alles können“. FLOW muss seinen Bereich kompromisslos gut können.

---

## Kernfunktionen

## 1. Deterministische Reparaturpipeline

Bestehende Pipeline: **SN → SL → MO → PG**.

Diese Einteilung ist stark, weil sie Fehlerklassen trennt:

* syntaktische / surface normalization
* syllabic / letter-pattern normalization
* morphological normalization
* phoneme–grapheme correction

Das ist mehr als Autocorrect. Es ist eine echte Produktlogik.

## 2. Grammar / Context Layer

Clause detection, context window rules, confidence filtering und grammar-oriented rules erweitern die Reparatur um kontrollierte Kontextsensitivität.

## 3. Lab / Benchmark Layer

FLOW enthält explizite Evaluationsoberflächen, Suite Runs, Promotion Flow und Testlogik. Das ist strategisch wertvoll, weil FLOW nicht nach „fühlt sich smarter an“ weiterentwickelt werden soll, sondern nach geringerem Schaden und besserer Retention valider Texte.

## 4. Native Shell / Echtzeitnutzung

Die Windows-Tray-Anbindung macht FLOW zu einem Werkzeug im tatsächlichen Schreiballtag, nicht nur zu einer Batch-Funktion.

## 5. Protected Spans

Technische Strings, URLs, Codefragmente etc. sollen geschützt bleiben, damit FLOW nicht an den falschen Stellen „hilft“.

---

## User Experience — Step by Step

### Einstieg

Nutzer:in schreibt in beliebiger Umgebung.

### FLOW greift früh, aber begrenzt ein

* lokale Korrektur
* keine stilistische Vereinnahmung
* keine langen Menüs
* keine generative Ersatzformulierung

### Ergebnis

Die Oberfläche wird stabiler. Nutzer:innen können weiterschreiben, ohne an banaler Reibung hängenzubleiben.

### Übergang

Sobald die Oberfläche ausreichend tragfähig ist:

* zu **SPIN**, wenn Ausdruck, Rhythmus oder Struktur Thema sind
* zu **SMASH**, wenn das Problem nicht Korrektur, sondern Blockade ist

---

## Zielgruppen

### Primär

* Nutzer:innen mit LRS-nahen Fehlerbildern
* Menschen mit hoher Reibung beim Tippen
* neurodivergente Nutzer:innen mit formaler Schreibhürde
* alle, die systemweite lokale Korrektur ohne generative Bevormundung wollen

### Sekundär

* pädagogische Kontexte
* datenschutzsensible Umgebungen
* Nutzer:innen, die klassische Cloud-Korrekturtools bewusst ablehnen

---

## Success Metrics

* Korrekturrate bei relevanten Fehlerklassen
* niedrige Damage-Rate an validem Text
* hohe Akzeptanz trotz deterministischem Ansatz
* messbare Reduktion von Schreibabbrüchen durch formale Reibung
* Nutzung in Echtzeit-Kontexten
* Benchmark-Fortschritt über definierte Suiten hinweg

---

## Technical Considerations

* Node-basierte Engine plus native Shell ist bereits sinnvoll angelegt
* Signalübergabe aus LOOM perspektivisch weiter vertiefen
* Confidence-Handling differenzieren: Auto-Repair vs. Vorschlag
* Regelbasis weiter ausbauen, aber bounded halten
* Cross-platform-Frage später klären, Windows-first ist für den Anfang okay

---

## Risiken

### 1. Scope Drift

FLOW könnte versucht sein, immer mehr Stil- oder Grammar-Aufgaben zu schlucken.

### 2. Überkorrektur

Wenn bounded repair in verdeckte Umformulierung kippt, verliert FLOW seine Glaubwürdigkeit.

### 3. Zu technische Wahrnehmung

Die Engine ist stark, aber die Produktbotschaft muss einfach bleiben.

### 4. Isolierte Positionierung

FLOW darf nicht so wirken, als sei es die ganze Produktwelt. Es ist die Reibungsschicht, nicht das Gesamtversprechen.

---

## Milestones & Sequencing

### Milestone 1

Reparaturpipeline und Benchmarking absichern

### Milestone 2

Grammar/context layer robust machen

### Milestone 3

UX für Echtzeitnutzung und Review verbessern

### Milestone 4

Saubere Übergänge zu SPIN und SMASH definieren

### Milestone 5

Domänen- oder zielgruppenspezifische Modulation prüfen

---

## Narrative

FLOW kümmert sich um die Stelle, an der viele andere Produkte zu früh ausufern. Es will nicht schönschreiben, nicht glätten, nicht klingen wie „bessere KI“. Es reduziert die Reibung, die Menschen vom Schreiben abhält, noch bevor Stil- oder Strukturfragen überhaupt sinnvoll bearbeitbar sind. Gerade dadurch ist FLOW strategisch wichtig: Es ist die Schicht, die den Text stabil genug macht, damit das eigentliche Arbeiten beginnen kann.
