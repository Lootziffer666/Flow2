import { spawn } from "node:child_process";

export function runCommand({ cmd, args, cwd, timeoutMs, env = {} }) {
  return new Promise((resolve, reject) => {
    const child = spawn(cmd, args, {
      cwd,
      shell: false,
      windowsHide: true,
      env: { PATH: process.env.PATH, ...env },
      stdio: ["ignore", "pipe", "pipe"],
    });

    let stdout = "";
    let stderr = "";

    child.stdout.on("data", (d) => (stdout += d.toString("utf8")));
    child.stderr.on("data", (d) => (stderr += d.toString("utf8")));

    const t = setTimeout(() => {
      child.kill("SIGKILL");
      reject(new Error("Command timeout"));
    }, timeoutMs);

    child.on("error", (e) => {
      clearTimeout(t);
      reject(e);
    });

    child.on("close", (code) => {
      clearTimeout(t);
      if (code !== 0) return reject(new Error(`Command failed (${code}): ${stderr.slice(0, 2000)}`));
      resolve({ stdout, stderr });
    });
  });
}
