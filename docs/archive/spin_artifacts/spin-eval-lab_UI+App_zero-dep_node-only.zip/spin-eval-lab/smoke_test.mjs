#!/usr/bin/env node
/**
 * smoke_test.mjs
 *
 * Zero-dependency smoke test:
 * - starts `runner/server.mjs` on an ephemeral port
 * - verifies key endpoints:
 *   - GET /api/health
 *   - GET /api/jobs
 *   - GET /
 * - shuts server down cleanly
 *
 * Usage:
 *   node smoke_test.mjs
 */
import assert from "node:assert/strict";
import http from "node:http";
import { spawn } from "node:child_process";
import net from "node:net";
import { setTimeout as delay } from "node:timers/promises";

function must(cond, msg) {
  if (!cond) throw new Error(msg);
}

async function getFreePort() {
  return await new Promise((resolve, reject) => {
    const s = net.createServer();
    s.on("error", reject);
    s.listen(0, "127.0.0.1", () => {
      const addr = s.address();
      s.close(() => resolve(addr.port));
    });
  });
}

async function httpGet(port, path) {
  return await new Promise((resolve, reject) => {
    const req = http.request(
      { host: "127.0.0.1", port, path, method: "GET", timeout: 5000 },
      (res) => {
        const chunks = [];
        res.on("data", (c) => chunks.push(c));
        res.on("end", () => {
          resolve({
            status: res.statusCode ?? 0,
            headers: res.headers,
            body: Buffer.concat(chunks).toString("utf-8"),
          });
        });
      }
    );
    req.on("timeout", () => req.destroy(new Error("request timeout")));
    req.on("error", reject);
    req.end();
  });
}

async function waitForHealthy(port, timeoutMs = 12_000) {
  const start = Date.now();
  // Backoff loop; avoids needing server-side readiness hooks.
  while (Date.now() - start < timeoutMs) {
    try {
      const r = await httpGet(port, "/api/health");
      if (r.status === 200) return r;
    } catch {
      // ignore until timeout
    }
    await delay(200);
  }
  throw new Error("server did not become healthy in time");
}

async function shutdown(proc, timeoutMs = 4000) {
  if (!proc || proc.killed) return;

  proc.kill("SIGTERM");

  const done = await Promise.race([
    new Promise((r) => proc.once("exit", r)),
    delay(timeoutMs).then(() => "timeout"),
  ]);

  if (done === "timeout") {
    proc.kill("SIGKILL");
    await Promise.race([new Promise((r) => proc.once("exit", r)), delay(2000)]);
  }
}

async function main() {
  const port = await getFreePort();

  const child = spawn(process.execPath, ["runner/server.mjs"], {
    env: { ...process.env, PORT: String(port) },
    stdio: "inherit",
  });

  try {
    await waitForHealthy(port);

    {
      const r = await httpGet(port, "/api/health");
      assert.equal(r.status, 200);
      const j = JSON.parse(r.body);
      must(j && j.ok === true, "health response malformed");
    }

    {
      const r = await httpGet(port, "/api/jobs");
      assert.equal(r.status, 200);
      const j = JSON.parse(r.body);
      must(Array.isArray(j) || (j && Array.isArray(j.jobs)), "jobs should be an array or {jobs: []}");
    }

    {
      const r = await httpGet(port, "/");
      assert.equal(r.status, 200);
      must(typeof r.body === "string" && r.body.length > 50, "UI HTML missing/too small");
      must(/scoredock/i.test(r.body) || /<title>/i.test(r.body), "UI HTML does not look like an app page");
    }

    console.log("SMOKE_OK");
  } finally {
    await shutdown(child);
  }
}

main().catch((err) => {
  console.error("SMOKE_FAIL:", err?.stack || String(err));
  process.exit(1);
});
