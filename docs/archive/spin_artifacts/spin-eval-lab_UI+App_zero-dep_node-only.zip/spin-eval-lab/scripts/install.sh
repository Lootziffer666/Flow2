#!/usr/bin/env bash
set -euo pipefail

# SPIN Evaluation Lab - bootstrap (macOS/Linux)
# Assumes: Node.js 18+ is installed.

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

echo "[1/3] Checking Node..."
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js is not installed. Install Node 18+ and retry."
  exit 1
fi
echo "Node version: $(node -v)"

echo "[2/3] Creating folders..."
mkdir -p private/_inbox private/tweaks private/runs lab/_inbox lab/artifacts public/releases

echo "[3/3] Writing example private artifact (if missing)..."
if [ ! -f private/_inbox/artifact.json ]; then
cat > private/_inbox/artifact.json <<'JSON'
{
  "artifact_id": "ART-PRIVATE-EXAMPLE",
  "source_run_id": "RUN-1044",
  "protocol_id": "PROTO-A",
  "protocol_version": "1.2.0",
  "protocol_hash": "PH-7F2B8E1C9A11",
  "env_fingerprint": "ENV-0A91C3D8",
  "code_version": "commit:local",
  "benchmark_suite_hash": "SUITE-9C3F2A1D7B44",
  "actor": "local-user",
  "created_at": "2026-03-02T00:00:00.000Z",
  "classification": "private_dev"
}
JSON
fi

echo "Done."
echo "Next:"
echo "  node runner/server.mjs"
