import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";

export const CLASSIFICATION = {
  PRIVATE_DEV: "private_dev",
  INTERNAL_BENCHMARK: "internal_benchmark",
  PUBLIC_RELEASE: "public_release",
};

export function normalizePath(p) {
  return path.resolve(p).replace(/\\/g, "/");
}

export function classifyPath(p) {
  const n = normalizePath(p);
  if (n.includes("/private/")) return CLASSIFICATION.PRIVATE_DEV;
  if (n.includes("/lab/")) return CLASSIFICATION.INTERNAL_BENCHMARK;
  if (n.includes("/public/")) return CLASSIFICATION.PUBLIC_RELEASE;
  return null;
}

// -------- Safety helpers (local-hardening) --------

export function assertId(id, name = "id") {
  const ok = typeof id === "string" && /^[a-z0-9_.-]+$/i.test(id) && id.length <= 128;
  if (!ok) throw new Error(`Invalid ${name}. Allowed: [a-z0-9_.-] (max 128).`);
}

export function safeJoin(baseDir, userPath) {
  if (typeof userPath !== "string" || userPath.length > 4096) {
    throw new Error("Invalid path input.");
  }
  if (userPath.includes("\0")) throw new Error("Invalid path input.");
  const base = normalizePath(baseDir);
  const target = normalizePath(path.join(base, userPath));
  if (!target.startsWith(base + "/") && target !== base) {
    throw new Error("Path traversal blocked.");
  }
  return target;
}

export function stableStringify(obj) {
  if (obj === null || typeof obj !== "object") return JSON.stringify(obj);
  if (Array.isArray(obj)) return "[" + obj.map(stableStringify).join(",") + "]";
  const keys = Object.keys(obj).sort();
  return "{" + keys.map(k => JSON.stringify(k) + ":" + stableStringify(obj[k])).join(",") + "}";
}

export function sha256(s) {
  return crypto.createHash("sha256").update(s).digest("hex");
}

export function canonicalHashJson(obj) {
  return sha256(stableStringify(obj));
}

// -------- Domain transition guards --------

export function assertNoPublicExportFromPrivate({ inputClassification, outDir }) {
  const outClass = classifyPath(outDir);
  if (inputClassification === CLASSIFICATION.PRIVATE_DEV && outClass === CLASSIFICATION.PUBLIC_RELEASE) {
    throw new Error("Illegal export: private_dev inputs may not write into public/.");
  }
}

export function assertSuiteOnly(inputClassification) {
  if (inputClassification !== CLASSIFICATION.PRIVATE_DEV) {
    throw new Error("Auto-tweak is Suite-only and requires classification=private_dev.");
  }
}

export function assertPromotionAllowed(inputClassification, targetClassification) {
  if (inputClassification === CLASSIFICATION.PRIVATE_DEV && targetClassification === CLASSIFICATION.INTERNAL_BENCHMARK) return;
  throw new Error(`Illegal transition: ${inputClassification} -> ${targetClassification}`);
}

export function assertReleaseAllowed(inputClassification, targetClassification) {
  if (inputClassification === CLASSIFICATION.INTERNAL_BENCHMARK && targetClassification === CLASSIFICATION.PUBLIC_RELEASE) return;
  throw new Error(`Illegal transition: ${inputClassification} -> ${targetClassification}`);
}

export function readJson(p) {
  return JSON.parse(fs.readFileSync(p, "utf-8"));
}

export function writeJson(p, obj) {
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, JSON.stringify(obj, null, 2) + "\n", "utf-8");
}
