export function isPlainObject(x) {
  return x !== null && typeof x === "object" && Object.getPrototypeOf(x) === Object.prototype;
}

export function assertKeys(obj, allowed) {
  for (const k of Object.keys(obj)) {
    if (!allowed.includes(k)) throw new Error(`Unexpected key: ${k}`);
  }
}

export function assertString(x, { min = 1, max = 200, name = "value", pattern = null } = {}) {
  if (typeof x !== "string") throw new Error(`${name} must be string`);
  if (x.length < min || x.length > max) throw new Error(`${name} length out of range`);
  if (pattern && !pattern.test(x)) throw new Error(`${name} invalid`);
  return x;
}

export function assertInt(x, { min = 0, max = 1e9, name = "value" } = {}) {
  if (!Number.isInteger(x)) throw new Error(`${name} must be int`);
  if (x < min || x > max) throw new Error(`${name} out of range`);
  return x;
}

export function assertBool(x, { name = "value" } = {}) {
  if (typeof x !== "boolean") throw new Error(`${name} must be boolean`);
  return x;
}

export function assertEnum(x, allowed, { name = "value" } = {}) {
  if (!allowed.includes(x)) throw new Error(`${name} must be one of: ${allowed.join(", ")}`);
  return x;
}
