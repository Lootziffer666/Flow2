/**
 * Tiny async job queue with max concurrency.
 */
export function createJobQueue({ maxConcurrent = 2 } = {}) {
  let running = 0;
  const q = [];

  async function runNext() {
    if (running >= maxConcurrent) return;
    const item = q.shift();
    if (!item) return;
    running++;
    try {
      const res = await item.fn();
      item.resolve(res);
    } catch (e) {
      item.reject(e);
    } finally {
      running--;
      queueMicrotask(runNext);
    }
  }

  function enqueue(fn) {
    return new Promise((resolve, reject) => {
      q.push({ fn, resolve, reject });
      queueMicrotask(runNext);
    });
  }

  return { enqueue, stats: () => ({ running, queued: q.length, maxConcurrent }) };
}
