# SPIN Evaluation Lab - bootstrap (Windows PowerShell)
# Assumes: Node.js 18+ is installed.

$ErrorActionPreference = "Stop"

$Root = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
Set-Location $Root

Write-Host "[1/3] Checking Node..."
if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
  Write-Host "Node.js is not installed. Install Node 18+ and retry."
  exit 1
}
Write-Host ("Node version: " + (node -v))

Write-Host "[2/3] Creating folders..."
$dirs = @(
  "private/_inbox",
  "private/tweaks",
  "private/runs",
  "lab/_inbox",
  "lab/artifacts",
  "public/releases"
)
foreach ($d in $dirs) { New-Item -ItemType Directory -Force -Path $d | Out-Null }

Write-Host "[3/3] Writing example private artifact (if missing)..."
$artifactPath = Join-Path $Root "private/_inbox/artifact.json"
if (-not (Test-Path $artifactPath)) {
@'
{
  "artifact_id": "ART-PRIVATE-EXAMPLE",
  "source_run_id": "RUN-1044",
  "protocol_id": "PROTO-A",
  "protocol_version": "1.2.0",
  "protocol_hash": "PH-7F2B8E1C9A11",
  "env_fingerprint": "ENV-0A91C3D8",
  "code_version": "commit:local",
  "benchmark_suite_hash": "SUITE-9C3F2A1D7B44",
  "actor": "local-user",
  "created_at": "2026-03-02T00:00:00.000Z",
  "classification": "private_dev"
}
'@ | Set-Content -Encoding UTF8 -Path $artifactPath
}

Write-Host "Done."
Write-Host "Next: node runner/server.mjs"
