# spin-eval-lab — Security Patch Pack (zero-dep, Node-only)

Dieses ZIP ist ein **drop-in Security-Modul-Paket** + **Integration-Snippets**, passend zu deiner Analyse:
- Strict Validation Layer (Whitelist, Regex, Limits)
- Body size limit + JSON reader
- child_process Hardening (no shell, timeouts, allowlist-kompatibel)
- Canonical JSON + SHA256
- Detached Signatures (Ed25519, Node built-in)
- Immutable / Write-once Artifact Store
- Verify-only CI Script
- Simple Rate limiting + Max concurrency (DOS-Bremse)
- Static file serving Hardening + Security Headers

> Hinweis: Ich kenne deinen exakten Repo-Aufbau nicht. Das Pack ist so gebaut, dass du es **1:1 als `security/` + `scripts/`** übernehmen kannst und danach pro Endpoint die Validatoren “einsteckst”.

---

## Quick Start (empfohlen)

1) Kopiere Ordner:
- `security/`
- `scripts/`

2) Setze Umgebungsvariablen:
- `STRICT_MODE=1`
- `ARTIFACT_DIR=./artifacts`
- `PUBLIC_KEY_PATH=./keys/public.pem`
- `PRIVATE_KEY_PATH=./keys/private.pem` (nur lokal/CI-secret)

3) Keys erzeugen (lokal):
```bash
node scripts/setupKeys.js
```

4) In CI (verify-only):
```bash
node scripts/verifyArtifacts.js --dir ./artifacts --pub ./keys/public.pem
```

---

## STRICT_MODE — “Security als Startbedingung”

- `security/strictMode.js` enthält einen Check, der das Starten verweigert, wenn Mindestschutz nicht aktiv ist.
- Idee: Wenn jemand aus Versehen Limits/Headers/Verify deaktiviert → **hard fail**.

Beispiel im Server-Entry:
```js
import { enforceStrictMode } from "./security/strictMode.js";
enforceStrictMode({
  strict: process.env.STRICT_MODE === "1",
  bindHost: process.env.BIND_HOST || "127.0.0.1",
  bodyMaxBytes: Number(process.env.BODY_MAX_BYTES || 65536),
});
```

---

## Validation Layer

- Baue pro Endpoint eine `validateXxx(body)` Funktion (Beispiel in `examples/validateRunRequest.js`).
- **Whitelist keys** + Typchecks + Regex + Längen/Range-Limits.
- IDs (flowId/datasetId) sind **IDs**, keine Pfade.

---

## child_process Hardening

- Nutze `spawn()` oder `execFile()` **ohne** `shell:true`.
- Keine untrusted Strings in args ohne Regex/Whitelist.
- Immer Timeout + Kill.

Siehe `security/exec.js`.

---

## Artifact Integrity (Hash + Signature + Immutable Store)

- `security/artifactStore.js` schreibt JSON canonicalized + `.sig.json` (Ed25519) + `.sha256`.
- Schreiben ist **write-once** (`wx`). Überschreiben ist ein Fehler.
- Lesen ist **verify-on-read**: kein Verify → kein Trust.

---

## DOS-Bremse

- `security/rateLimit.js`: Token Bucket per IP.
- `security/jobQueue.js`: Max parallel Jobs (concurrency cap).

---

## Static file serving + Headers

- `security/staticServe.js`: Path traversal Schutz, keine Directory Listings.
- `security/headers.js`: nosniff + basic CSP + no-store für HTML.

---

## Dateien

- `security/validate.js` — mini validator toolkit
- `security/readJson.js` — JSON reader mit body-size limit
- `security/exec.js` — spawn wrapper (no shell, timeout)
- `security/canonicalJson.js` — canonical stringify
- `security/hash.js` — sha256 helper
- `security/sign.js` — Ed25519 sign/verify
- `security/atomicWrite.js` — write-once helper
- `security/artifactStore.js` — signed artifacts + verify-on-read
- `security/rateLimit.js` — token bucket
- `security/jobQueue.js` — concurrency cap queue
- `security/staticServe.js` — safe static serving
- `security/headers.js` — security headers
- `security/strictMode.js` — startup invariants
- `scripts/setupKeys.js` — key generation
- `scripts/verifyArtifacts.js` — verify-only scanner
- `examples/httpServerSkeleton.js` — minimal Integration Beispiel (Node http)

---

## Minimaler Integrationspfad (realistisch)

1) Server start: `enforceStrictMode()` + headers + body limit.
2) `/api/run`: `readJson()` → `validateRunRequest()` → queue job → artifactStore.writeJsonSigned()
3) `/api/artifact/:id`: **verify-on-read** → return.
4) CI: `verifyArtifacts.js`

