# PRD — SMASH

## Entblockungsschicht für Schreibfähigkeit statt Textproduktion

## TL;DR

**SMASH** ist ein Tool zur Unterbrechung von Schreibblockaden.
Es soll **nicht schreiben**, sondern dabei helfen, wieder **schreibfähig** zu werden.

Der Ansatz ist bewusst nicht:
„Hier ist noch ein Prompt“
oder
„Hier ist noch ein KI-Textvorschlag“.

Stattdessen fokussiert SMASH auf **kurze, gezielte Interventionen**, die festgefahrene Zustände aufbrechen und den Übergang zurück ins Schreiben erleichtern.

---

## Problem

„Schreibblockade“ ist kein einheitliches Problem.

Hinter demselben sichtbaren Ergebnis — jemand schreibt nicht weiter — können sehr unterschiedliche Ursachen stehen, zum Beispiel:

* kein Zugriff auf die nächste Idee
* Überlastung durch zu viele Möglichkeiten
* innerer Perfektionismus
* Verlust des roten Fadens
* festgefahrener Satz oder Absatz
* mentaler Leerlauf trotz grundsätzlicher Schreibbereitschaft

SMASH behandelt diese Zustände nicht als moralisches Versagen und auch nicht als Aufforderung zu generativer Ersetzung, sondern als **unterschiedliche Blockadetypen**, die unterschiedliche Interventionen brauchen.

---

## Produktziel

SMASH soll kurze, gezielte Interventionsmechaniken anbieten, die:

* Blockadezustände aufbrechen
* Reibung senken
* Handlung wiederherstellen
* nicht vom eigentlichen Schreiben wegführen
* keine Autorschaft übernehmen

---

## Business Goals

* Eine glaubwürdige nicht-generative Antwort auf Schreibblockaden schaffen
* Das Portfolio um eine zustandsbezogene Ebene ergänzen
* SPIN sinnvoll erweitern, ohne dessen Kern zu verwässern
* Eine starke Nische zwischen Schreibcoaching, Pomodoro-Tools und AI-Writing besetzen

---

## User Goals

* Ich will wieder ins Schreiben kommen, ohne dass mir Text geliefert wird
* Ich will nicht analysiert oder belehrt werden, wenn ich festhänge
* Ich brauche einen kleinen Hebel, keinen Ersatzprozess
* Ich will schnell zurück in echte Handlung

---

## Non-Goals

SMASH ist nicht:

* ein AI-Writer
* ein Promptgenerator
* ein Casual Game
* ein Produktivitäts-Tracker
* ein Schreibkurs
* eine Dauerbeschäftigung
* eine Ablenkungsmaschine mit hübscher Verpackung

---

## Produktprinzipien

### 1. Intervention statt Ersetzung

### 2. Kurz statt ausufernd

### 3. Rückführung statt Paralleluniversum

### 4. Unterschiedliche Blockaden brauchen unterschiedliche Mechaniken

### 5. Frictionless Einstieg ist Pflicht

---

## Rolle im Ökosystem

* **LOOM** hilft beim Erkennen von Zustandsmustern
* **FLOW** beseitigt frühe formale Reibung
* **SPIN** macht Ausdrucks- und Strukturprobleme sichtbar
* **SMASH** greift dort ein, wo Schreiben trotzdem festhängt

SMASH ist damit keine Konkurrenz zu SPIN, sondern eine **gezielte Rückführungs- und Entlastungsschicht**.

---

## Kernfunktionen

### 1. Mikrointerventionen

Sehr kurze Interventionen mit klarer Rückkehr in den Text.

### 2. Blockadetyp-nahe Auswahl

Interventionen richten sich nach vermutetem Zustand statt nach Einheitslogik.

### 3. Rückführungsmechanik

Nach der Intervention muss der Weg zurück in den Text zentral und leicht sein.

### 4. Spätere Signalschnittstellen

SMASH soll perspektivisch Signale aus LOOM und SPIN nutzen können, um Interventionen genauer zu wählen.

---

## MVP

* erste kuratierte Interventionsbibliothek
* schneller Einstieg ohne Setup-Overkill
* klare Rückkehr in SPIN oder den Text
* einfache Messung: wurde danach wieder geschrieben?

---

## Risiken

* Intervention wird selbst zur Vermeidungsstrategie
* zu viel Gamification
* zu wenig Trennschärfe zwischen Blockadetypen
* Rückweg in den Text ist zu schwach oder zu versteckt

---

## Erfolgsmetriken

* schneller Start je Intervention
* echte Rückkehr in Handlung
* niedrige Abbruchquote
* qualitative Wahrnehmung: hilfreich, nicht albern, nicht bevormundend
* sinnvolle Nutzung als Ergänzung zu SPIN statt als Flucht vor Textarbeit

---

## Narrative

SMASH ist nicht dazu da, das Schreiben zu übernehmen.
Es ist dazu da, den Moment zu überbrücken, in dem Schreiben gerade nicht zugänglich ist.

Nicht mehr.
Aber auch nicht weniger.
