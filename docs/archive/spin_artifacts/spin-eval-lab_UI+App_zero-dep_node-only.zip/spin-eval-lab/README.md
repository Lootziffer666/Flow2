# SPIN Evaluation Lab

## Zero-dependency quickstart (Node only)

```bash
node runner/server.mjs
# UI:  http://127.0.0.1:8787/
# API: http://127.0.0.1:8787/api/health
```

### Smoke test (CI/local)

```bash
node smoke_test.mjs
```



## Zero-build UI (recommended for fast local runs)

Run API + UI with no build step:

```bash
node runner/server.mjs
```

Open:
- UI: http://127.0.0.1:8787/
- API health: http://127.0.0.1:8787/api/health


---

SPIN Evaluation Lab is a deterministic benchmarking and promotion system for FLOW protocol runs.

It enforces strict separation between:

- Test Suite mode (mode-suite, forced light): iterative testing, debugging, candidate selection
- Lab mode (mode-lab, forced dark): immutable benchmarking, audit-tracked promotion, reproducible results

Theme is controlled exclusively via `<html>` class:
- mode-suite
- mode-lab

---

# Core Concepts

## Run Bundle

A Run Bundle represents a FLOW protocol execution result:

Fields:

- run_id
- protocol_id
- protocol_version
- protocol_hash
- env_fingerprint
- code_version
- created_at
- status

Statuses:

- uploaded
- verifying
- verified
- failed

Only verified runs may be promoted.

---

## Candidate

A Candidate is a verified run bundle selected for possible promotion.

Candidate selection does not modify the run.

Promotion must be explicitly authorized via Promote Wizard.

---

## Artifact

Promotion produces an Artifact.

Artifact properties:

- artifact_id
- source_run_id
- protocol_hash
- benchmark_suite_hash
- env_fingerprint
- code_version
- actor
- created_at

Artifacts are immutable.

Artifacts are the root of benchmark execution.

---

## Benchmark Jobs

Each artifact triggers benchmark jobs.

Lifecycle:

Queued → Running → Complete

These jobs are deterministic under identical protocol, dataset, and environment conditions.

---

# Determinism Guarantees

Each artifact contains sufficient fingerprint data to reproduce:

- protocol
- dataset hashes
- environment
- code version

Audit trail is preserved.

---

# Development (Node only)

No build step is required. The UI is served from `./ui` as static files.

```bash
node runner/server.mjs
node smoke_test.mjs
node --test
node scripts/ci_verify.mjs
```


# Repository Structure

```
ui/            Zero-build frontend (static)
runner/        Unified server (API + UI)
scripts/       CLI utilities (hashing, benchmarks, CI verify)
protocol/      Protocol definition + hashes
datasets/      Benchmark datasets
benchmarks/    Suite definitions
lab/           Lab-mode outputs (default allowlist)
private/       Private-mode outputs (default allowlist)
```

---

# Promotion Flow

1. Run appears in Suite
2. Run reaches verified
3. User marks Candidate
4. User opens Promote Wizard
5. User re-authenticates and confirms
6. Artifact created
7. Mode switches to Lab
8. Benchmarks execute
9. Audit log recorded

---

# Scientific Integrity Model

This system is designed to support:

- deterministic evaluation
- dataset provenance
- protocol immutability
- auditability
- reproducible benchmarking

No benchmark result exists without provenance.

---

# Future Extensions

Planned:

- dataset hashing
- environment manifests
- protocol registry
- contamination checks
- signed artifact chain
- CI automation

---

## Privacy & Non-Disclosure

**Testlab (private_dev) must never become public.** This repository enforces that rule at the script level.

Domains:

- `private/` → classification `private_dev`
- `lab/` → classification `internal_benchmark`
- `public/` → classification `public_release`

Allowed transitions:

- `private_dev` → `internal_benchmark` (promotion only)
- `internal_benchmark` → `public_release` (explicit export only)

Scripts refuse illegal transitions and refuse writing private_dev outputs into `public/`.

Key scripts:

- `scripts/auto_tweak.mjs` — Suite-only scheduled auto-tweak (writes only to `private/`)
- `scripts/generate_artifact.mjs` — Promotion gate (private_dev → internal_benchmark)
- `scripts/run_benchmarks.mjs` — Benchmark runner (export guards)
- `scripts/export_public.mjs` — Explicit public export (internal_benchmark → public_release)

---

## Quickstart

1) Bootstrap folders + example artifact (optional but recommended)

- Windows PowerShell: `./scripts/install.ps1`
- macOS/Linux: `chmod +x ./scripts/install.sh && ./scripts/install.sh`

2) Start UI + API (single process)

```bash
node runner/server.mjs
```

3) Open:

- UI: http://127.0.0.1:8787/
- API health: http://127.0.0.1:8787/api/health

### Smoke test

```bash
node smoke_test.mjs
```

