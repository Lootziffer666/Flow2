# Export-Paket — LOOM / FLOW / SPIN / SMASH

## Inhalt

- 01_PRD_LOOM.md
- 02_PRD_FLOW.md
- 03_PRD_SPIN.md
- 04_PORTFOLIO_PRD_LOOM_FLOW_SPIN_SMASH.md
- 05_PRD_SMASH.md

## Hinweis

SPIN wurde exakt so weit übernommen, wie es im gelieferten Material enthalten war.
Der SPIN-Text endet daher nach den ersten vier Kernfunktionen und ist nicht künstlich ergänzt worden.
