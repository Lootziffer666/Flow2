import path from "node:path";
import { mkdir, readFile } from "node:fs/promises";
import { canonicalStringify } from "./canonicalJson.js";
import { sha256Hex } from "./hash.js";
import { signBytes, verifyBytes } from "./sign.js";
import { writeFileExclusive } from "./atomicWrite.js";

export async function createRunDir(baseDir, runId) {
  const dir = path.join(baseDir, runId);
  // write-once: fail if exists
  await mkdir(dir, { recursive: false });
  return dir;
}

export async function writeJsonSigned(runDir, name, obj, privatePem) {
  const canonical = canonicalStringify(obj);
  const dataBuf = Buffer.from(canonical, "utf8");
  const hash = sha256Hex(dataBuf);
  const sig = signBytes(dataBuf, privatePem).toString("base64");

  const jsonPath = path.join(runDir, `${name}.json`);
  const sigPath = path.join(runDir, `${name}.sig.json`);
  const hashPath = path.join(runDir, `${name}.sha256`);

  await writeFileExclusive(jsonPath, canonical + "\n");
  await writeFileExclusive(sigPath, JSON.stringify({ alg: "Ed25519", sig, hash }, null, 2) + "\n");
  await writeFileExclusive(hashPath, hash + "\n");

  return { hash, sigBase64: sig };
}

export async function readJsonVerified(runDir, name, publicPem) {
  const jsonPath = path.join(runDir, `${name}.json`);
  const sigPath = path.join(runDir, `${name}.sig.json`);

  const raw = await readFile(jsonPath, "utf8");
  const obj = JSON.parse(raw);

  const canonical = canonicalStringify(obj);
  const dataBuf = Buffer.from(canonical, "utf8");

  const sigMeta = JSON.parse(await readFile(sigPath, "utf8"));
  if (sigMeta.alg !== "Ed25519") throw new Error("Unsupported signature algorithm");
  const sigBuf = Buffer.from(sigMeta.sig, "base64");

  const ok = verifyBytes(dataBuf, sigBuf, publicPem);
  if (!ok) throw new Error("Signature verification failed");

  const hash = sha256Hex(dataBuf);
  if (sigMeta.hash && sigMeta.hash !== hash) throw new Error("Hash mismatch");

  return obj;
}
