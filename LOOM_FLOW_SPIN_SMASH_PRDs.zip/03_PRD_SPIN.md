# PRD — SPIN

## Strukturelles Schreiblabor für Ausdruck, Rhythmus, Leselast und Kohärenz

## TL;DR

**SPIN** ist die operative Ausdrucks- und Analyseoberfläche des Systems.
Wenn LOOM die zugrunde liegende Sprachlogik ist und FLOW frühe Oberflächenreibung reduziert, dann ist SPIN der Ort, an dem Autor:innen ihren Text als **bewegliche Struktur** bearbeiten, beobachten, vergleichen und schärfen.

SPIN ist kein Korrektor und kein AI-Writer. SPIN ist ein **Schreiblabor**, das Rhythmus, Leselast, Wiederholung und strukturelle Spannungen sichtbar macht, ohne die Stimme des Autors zu ersetzen.

---

## Problem Statement

Selbst wenn Orthografie stabil ist, bleibt Schreiben schwer.

Warum?

Weil viele Probleme nicht auf der Fehlerschicht liegen, sondern auf der **Ausdrucks- und Strukturwahrnehmung**:

* ein Satz klingt schwer
* ein Absatz ermüdet
* ein Text wird monoton
* Wiederholungen kippen von Motiv zu Last
* eine Struktur wirkt dicht, ohne klar falsch zu sein
* Varianten existieren, aber keine ist offensichtlich „die richtige“

Bestehende Tools reagieren darauf meist mit einer falschen Geste:
Sie schlagen direkt neue Formulierungen vor.

Für viele ernsthafte Schreibende ist das unbrauchbar. Sie wollen nicht ersetzt, sondern **wahrnehmungsfähiger** werden.

---

## Produktziel

SPIN soll Autor:innen helfen,

* den eigenen Text präziser zu sehen,
* Ausdrucksprobleme lokal zu erkennen,
* Varianten ohne Normierungsdruck zu prüfen,
* strukturelle Belastung, Rhythmus und Monotonie sichtbar zu machen,
* und selbstbestimmt zu überarbeiten.

SPIN macht nicht „den besseren Text“.
SPIN macht den **eigenen Text besser lesbar für seinen Autor**.

---

## Business Goals

* Eine klare Gegenposition zu generativen Schreibtools besetzen
* Eine eigenständige Kategorie definieren: diagnostisches Schreiblabor
* Loyale Nutzergruppen im Bereich bewussten Schreibens gewinnen
* SPIN als Herzstück des Ökosystems positionieren
* Eine Oberfläche schaffen, die LOOMs Strukturintelligenz produktiv erfahrbar macht

---

## User Goals

* Ich will meinen eigenen Stil verbessern, ohne ihn ersetzen zu lassen
* Ich will sehen, wo mein Text schwer, dicht oder monoton wird
* Ich will Varianten vergleichen, ohne dass mir eine Maschine die „beste“ diktiert
* Ich will Hinweise, keine Bevormundung
* Ich will in einer ruhigen Umgebung arbeiten

---

## Non-Goals

SPIN ist nicht:

* ein Grammatikprüfer
* ein SEO-Tool
* ein AI-Writer
* ein Auto-Rewrite-System
* ein „optimiere meinen Text“-Button
* ein allgemeines Produktivitätsdashboard
* eine lineare „Version 2 ist besser als Version 1“-Maschine

---

## Produktprinzipien

### 1. Sichtbarmachung statt Ersetzung

### 2. Ausdruck vor Normierung

### 3. Ruhe statt Feature-Cockpit

### 4. Varianten als Möglichkeiten, nicht als Urteilskette

### 5. Unterschiedliche Probleme brauchen unterschiedliche Visualisierungen

---

## Produktlogik

SPIN steht **auf LOOM** und arbeitet **nach FLOW**.

* **LOOM** liefert Chunking, Strukturdiagnose, Re-Render-Grundlage
* **FLOW** sorgt dafür, dass banale Oberflächenreibung nicht alles überlagert
* **SPIN** ist dann die Ebene, auf der der Mensch tatsächlich mit Ausdruck arbeitet

Das ist wichtig: SPIN darf nicht wie ein losgelöstes Tool beschrieben werden. Es ist die **sichtbare Arbeitsfläche** eines tieferen Systems.

---

## Kernfunktionen

### 1. Leselast-Oszilloskop

Visualisiert lokale Leselast statt global zu bewerten.

### 2. Rhythmus-Glättung im Referenzmodus

Zeigt eine geglättete Referenzstruktur, ohne sie in den Text zu übernehmen.

### 3. Wortfriedhof

Sammelt entfernte oder verdächtige Wörter/Phrasen reversibel.

### 4. Motiv- und Wiederholungs-Tracker

Unterscheidet zwischen wiederkehrend und auffällig gehäuft.
