# Local-only Security Posture (Hardening Notes)

Dieses Repo ist für **Single-User lokale Nutzung** gedacht (kein untrusted traffic).
Trotzdem gibt es ein paar Low-Effort/High-Value Schutzmaßnahmen, die vor allem gegen
**Selbstschäden** helfen (falscher Pfad, zu viele Klicks, riesige Payloads, phantom diffs).

## Implementiert

- Keine `exec()`-String-Interpolation. Runner nutzt `spawn(..., { shell:false })` explizit.
- Runner bindet an `127.0.0.1` (nicht `0.0.0.0`).
- Path Traversal Guard: `safeJoin(root, userPath)`.
- ID-Allowlist: `^[a-z0-9_.-]+$` (max 128).
- Request Body Limit: `MAX_BODY_BYTES` (default 256KB).
- Concurrency Limit + Queue: `MAX_CONCURRENT_JOBS` (default 2).
- Deterministische Hashes per canonical JSON (Protocol + Suite + Env snapshots).

## Konfiguration (optional)

Environment variables:

- `MAX_CONCURRENT_JOBS` (default `2`)
- `MAX_BODY_BYTES` (default `262144`)

Beispiel:
```bash
MAX_CONCURRENT_JOBS=1 MAX_BODY_BYTES=131072 node runner/server.mjs
```


## UI Sanity Guards

- Runner controls use dropdown allowlists (`/api/options`) instead of free-text paths.
- Server enforces the same allowlists.

- Mode-aware filtering: Suite mode only shows private/_inbox artifacts and writes to private/runs; Lab mode only shows lab/_inbox artifacts and writes to lab/artifacts.
