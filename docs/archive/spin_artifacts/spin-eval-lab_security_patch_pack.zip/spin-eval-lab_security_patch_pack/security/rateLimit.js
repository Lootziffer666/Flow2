/**
 * Simple token-bucket rate limiter (zero-dep).
 * Use per IP (or per API key) + per route if desired.
 */
export function createRateLimiter({
  capacity = 60,         // tokens
  refillPerSec = 1,      // tokens per second
  now = () => Date.now(),
} = {}) {
  const buckets = new Map();

  function getBucket(key) {
    let b = buckets.get(key);
    if (!b) {
      b = { tokens: capacity, last: now() };
      buckets.set(key, b);
    }
    const t = now();
    const elapsed = Math.max(0, (t - b.last) / 1000);
    b.tokens = Math.min(capacity, b.tokens + elapsed * refillPerSec);
    b.last = t;
    return b;
  }

  function take(key, cost = 1) {
    const b = getBucket(key);
    if (b.tokens < cost) return false;
    b.tokens -= cost;
    return true;
  }

  return { take };
}
