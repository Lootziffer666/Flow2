#!/usr/bin/env node
/**
 * Unified Runner Service (no deps) + Zero-build UI
 *
 * Goals:
 * - Single command: `node runner/server.mjs` runs API + serves UI (no build tool required).
 * - Local-only posture: binds to 127.0.0.1
 * - Hardening: path traversal guard, id allowlist, body size limit, concurrency limit
 *
 * UI:
 * - Serves ./ui at /
 * - Hash routing is supported (fallback to ui/index.html for non-file paths).
 *
 * API:
 * - GET  /api/health
 * - GET  /api/jobs
 * - GET  /api/jobs/:id
 * - GET  /api/logs/:id?tail=20000
 * - POST /api/bench
 * - POST /api/tweak
 * - GET  /api/events (optional SSE; best-effort)
 */
import http from "node:http";
import { spawn } from "node:child_process";
import url from "node:url";
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";

import { assertId, safeJoin, classifyPath } from "../scripts/guards.mjs";

const HOST = "127.0.0.1";
const PORT = Number(process.env.PORT ?? "8787");
const ROOT = process.cwd();
const UI_DIR = path.join(ROOT, "ui");

const MAX_BODY_BYTES = Number(process.env.MAX_BODY_BYTES ?? "262144"); // 256KB
const MAX_CONCURRENT_JOBS = Number(process.env.MAX_CONCURRENT_JOBS ?? "2");

// repo-relative allowlists
const ALLOWED_ARTIFACT_ROOTS = ["private/_inbox", "lab/_inbox"];
const ALLOWED_OUTDIR_BENCH = ["private/runs", "lab/artifacts"];
const ALLOWED_OUTDIR_TWEAK = ["private/tweaks"];

const jobs = new Map(); // jobId -> job
const queue = [];
let running = 0;

// Optional SSE stream clients
const sseClients = new Set();

function sha256(s) {
  return crypto.createHash("sha256").update(s).digest("hex");
}

function nowIso() {
  return new Date().toISOString();
}

function json(res, status, obj) {
  const body = JSON.stringify(obj, null, 2);
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
  });
  res.end(body);
}

function text(res, status, body, contentType = "text/plain; charset=utf-8") {
  res.writeHead(status, { "Content-Type": contentType, "Cache-Control": "no-store" });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = "";
    let bytes = 0;

    req.on("data", (chunk) => {
      bytes += chunk.length;
      if (bytes > MAX_BODY_BYTES) {
        reject(new Error("Request body too large."));
        req.destroy();
        return;
      }
      data += chunk.toString("utf-8");
    });

    req.on("end", () => {
      if (!data) return resolve({});
      try {
        resolve(JSON.parse(data));
      } catch {
        reject(new Error("Invalid JSON body"));
      }
    });
  });
}

function broadcastSse(event, payload) {
  const msg = `event: ${event}\ndata: ${JSON.stringify(payload)}\n\n`;
  for (const res of sseClients) {
    try {
      res.write(msg);
    } catch {
      sseClients.delete(res);
    }
  }
}

function publicJob(j) {
  return {
    id: j.id,
    kind: j.kind,
    status: j.status,
    startedAt: j.startedAt,
    endedAt: j.endedAt,
    exitCode: j.exitCode,
  };
}

function canStartNow() {
  return running < MAX_CONCURRENT_JOBS;
}

function pumpQueue() {
  while (canStartNow() && queue.length > 0) {
    const fn = queue.shift();
    fn();
  }
}

function startJobQueued({ kind, args, env }) {
  const id = `JOB-${sha256(`${kind}|${nowIso()}|${Math.random()}`).slice(0, 10).toUpperCase()}`;

  const job = {
    id,
    kind,
    status: "queued",
    startedAt: nowIso(),
    endedAt: null,
    cmd: process.execPath,
    args,
    log: "",
    exitCode: null,
  };

  jobs.set(id, job);
  broadcastSse("job", { type: "created", job: publicJob(job) });

  const launch = () => {
    job.status = "running";
    job.startedAt = nowIso();
    running++;

    broadcastSse("job", { type: "updated", job: publicJob(job) });

    const child = spawn(process.execPath, args, {
      env: { ...process.env, ...(env || {}) },
      stdio: ["ignore", "pipe", "pipe"],
      shell: false,
    });

    const onChunk = (d) => {
      job.log += d.toString("utf-8");
      if (job.log.length > 2_000_000) job.log = job.log.slice(-2_000_000);
      broadcastSse("log", { jobId: job.id, chunk: d.toString("utf-8") });
    };

    child.stdout.on("data", onChunk);
    child.stderr.on("data", onChunk);

    child.on("close", (code) => {
      job.status = code === 0 ? "complete" : "failed";
      job.exitCode = code;
      job.endedAt = nowIso();
      running = Math.max(0, running - 1);

      broadcastSse("job", { type: "updated", job: publicJob(job) });

      pumpQueue();
    });
  };

  if (canStartNow()) launch();
  else queue.push(launch);

  return job;
}

function requireDomain(p) {
  const cls = classifyPath(p);
  if (!cls) throw new Error("Path must be under private/, lab/, or public/.");
  return cls;
}

function contentTypeFor(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  switch (ext) {
    case ".html":
      return "text/html; charset=utf-8";
    case ".css":
      return "text/css; charset=utf-8";
    case ".js":
    case ".mjs":
      return "text/javascript; charset=utf-8";
    case ".json":
      return "application/json; charset=utf-8";
    case ".svg":
      return "image/svg+xml";
    case ".png":
      return "image/png";
    case ".jpg":
    case ".jpeg":
      return "image/jpeg";
    default:
      return "application/octet-stream";
  }
}

function serveUi(req, res) {
  const u = url.parse(req.url || "", true);
  let pathname = u.pathname || "/";
  if (pathname === "/") pathname = "/index.html";

  // Normalize + decode
  let rel = pathname.replace(/^\/+/, ""); // strip leading slash
  try {
    rel = decodeURIComponent(rel);
  } catch {
    return text(res, 400, "Bad request path");
  }

  // Directories -> index.html
  if (rel.endsWith("/")) rel = rel + "index.html";

  // Block weird absolute paths
  if (rel.startsWith("..") || rel.includes("\\") || rel.includes("\0")) {
    return text(res, 400, "Bad request path");
  }

  const wantsFile = path.extname(rel) !== "";

  let abs;
  try {
    abs = safeJoin(UI_DIR, rel);
  } catch {
    return text(res, 400, "Bad request path");
  }

  if (!fs.existsSync(abs) || !fs.statSync(abs).isFile()) {
    // Hash router is used, but we still allow non-file paths to fall back to index.html.
    if (!wantsFile) {
      const indexAbs = safeJoin(UI_DIR, "index.html");
      return streamFile(res, indexAbs);
    }
    return text(res, 404, "Not found");
  }

  return streamFile(res, abs);
}

function streamFile(res, absPath) {
  const ct = contentTypeFor(absPath);
  res.writeHead(200, { "Content-Type": ct, "Cache-Control": "no-store" });
  fs.createReadStream(absPath).pipe(res);
}

function listJobs() {
  return Array.from(jobs.values())
    .map(publicJob)
    .sort((a, b) => String(b.startedAt || "").localeCompare(String(a.startedAt || "")));
}

const server = http.createServer(async (req, res) => {
  const u = url.parse(req.url || "", true);
  const method = req.method || "GET";
  const pathname = u.pathname || "/";

  // UI
  if (!pathname.startsWith("/api/")) {
    if (method !== "GET" && method !== "HEAD") return text(res, 405, "Method not allowed");
    return serveUi(req, res);
  }

  // API: health
  if (method === "GET" && pathname === "/api/health") {
    return json(res, 200, {
      ok: true,
      service: "spin-runner",
      time: nowIso(),
      concurrency: { running, max: MAX_CONCURRENT_JOBS, queued: queue.length },
    });
  }

  // API: SSE events
  if (method === "GET" && pathname === "/api/events") {
    res.writeHead(200, {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-store",
      Connection: "keep-alive",
    });
    res.write("\n");
    sseClients.add(res);
    req.on("close", () => sseClients.delete(res));
    return;
  }

  // API: jobs list
  if (method === "GET" && pathname === "/api/jobs") {
    return json(res, 200, { jobs: listJobs() });
  }

  // API: job by id
  if (method === "GET" && pathname.startsWith("/api/jobs/")) {
    const id = pathname.slice("/api/jobs/".length);
    try {
      assertId(id, "jobId");
    } catch (e) {
      return json(res, 400, { error: "invalid_request", message: String(e.message || e) });
    }
    const j = jobs.get(id);
    if (!j) return json(res, 404, { error: "not_found", message: "Unknown jobId" });
    return json(res, 200, publicJob(j));
  }

  // API: logs
  if (method === "GET" && pathname.startsWith("/api/logs/")) {
    const id = pathname.slice("/api/logs/".length);
    try {
      assertId(id, "jobId");
    } catch (e) {
      return json(res, 400, { error: "invalid_request", message: String(e.message || e) });
    }
    const j = jobs.get(id);
    if (!j) return json(res, 404, { error: "not_found", message: "Unknown jobId" });

    const tail = u.query?.tail ? Number(u.query.tail) : null;
    const log = (tail && Number.isFinite(tail) && tail > 0) ? String(j.log || "").slice(-tail) : String(j.log || "");
    return json(res, 200, { id: j.id, status: j.status, log });
  }

  // API: bench
  if (method === "POST" && pathname === "/api/bench") {
    try {
      const body = await readBody(req);
      const artifactPathRel = body.artifactPath;
      const outDirRel = body.outDir;
      const flowCmd = body.flowCmd || process.env.FLOW_CMD;

      if (!artifactPathRel) return json(res, 400, { error: "artifactPath_required" });
      if (!outDirRel) return json(res, 400, { error: "outDir_required" });

      const aRel = String(artifactPathRel);
      const oRel = String(outDirRel);

      if (!ALLOWED_ARTIFACT_ROOTS.some((root) => aRel.startsWith(root + "/") || aRel === root)) {
        throw new Error("Refusing: artifactPath not allowlisted.");
      }
      if (!ALLOWED_OUTDIR_BENCH.includes(oRel)) {
        throw new Error("Refusing: outDir not allowlisted for bench.");
      }

      // Mode inference: suite benches must use suite artifacts; lab benches must use lab artifacts
      if (oRel === "private/runs" && !aRel.startsWith("private/_inbox/")) {
        throw new Error("Refusing: suite bench requires artifact under private/_inbox.");
      }
      if (oRel === "lab/artifacts" && !aRel.startsWith("lab/_inbox/")) {
        throw new Error("Refusing: lab bench requires artifact under lab/_inbox.");
      }

      const artifactAbs = safeJoin(ROOT, aRel);
      const outAbs = safeJoin(ROOT, oRel);

      const aCls = requireDomain(artifactAbs);
      const oCls = requireDomain(outAbs);

      if (oCls === "public_release") throw new Error("Refusing to run benchmarks into public/.");

      // Keep "unused variable" linters calm; these are intentionally computed for safety checks.
      void aCls;

      const args = ["scripts/run_benchmarks.mjs", "--artifact", aRel, "--out", oRel];
      if (body.policyPath) args.push("--policy", String(body.policyPath));
      if (body.suitePath) args.push("--suite", String(body.suitePath));
      if (body.seed) args.push("--seed", String(body.seed));
      if (flowCmd) args.push("--flowCmd", String(flowCmd));

      const job = startJobQueued({ kind: "bench", args, env: {} });
      return json(res, 202, { jobId: job.id });
    } catch (e) {
      return json(res, 400, { error: "invalid_request", message: String(e.message || e) });
    }
  }

  // API: tweak (suite-only)
  if (method === "POST" && pathname === "/api/tweak") {
    try {
      const body = await readBody(req);
      const artifactPathRel = body.artifactPath;
      const minutes = body.minutes ?? 10;
      const outDirRel = "private/tweaks";

      if (!artifactPathRel) return json(res, 400, { error: "artifactPath_required" });

      const aRel = String(artifactPathRel);
      if (!ALLOWED_ARTIFACT_ROOTS.some((root) => aRel.startsWith(root + "/") || aRel === root)) {
        throw new Error("Refusing: artifactPath not allowlisted.");
      }

      const artifactAbs = safeJoin(ROOT, aRel);
      requireDomain(artifactAbs);

      const args = ["scripts/auto_tweak.mjs", "--minutes", String(minutes), "--artifact", aRel, "--out", outDirRel];
      if (body.objective) args.push("--objective", String(body.objective));
      if (body.seed) args.push("--seed", String(body.seed));

      const job = startJobQueued({ kind: "tweak", args, env: {} });
      return json(res, 202, { jobId: job.id });
    } catch (e) {
      return json(res, 400, { error: "invalid_request", message: String(e.message || e) });
    }
  }

  return json(res, 404, { error: "not_found" });
});

server.listen(PORT, HOST, () => {
  console.log(`ScoreDock listening on http://${HOST}:${PORT}`);
  console.log(`UI: http://${HOST}:${PORT}/  (served from ./ui)`);
  console.log(`API: http://${HOST}:${PORT}/api/health`);
  console.log(`Local hardening: MAX_CONCURRENT_JOBS=${MAX_CONCURRENT_JOBS} MAX_BODY_BYTES=${MAX_BODY_BYTES}`);
});
