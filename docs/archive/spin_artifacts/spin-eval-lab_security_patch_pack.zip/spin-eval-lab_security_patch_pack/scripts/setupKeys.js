import { generateKeyPairSync } from "node:crypto";
import { writeFileSync, mkdirSync } from "node:fs";

mkdirSync("keys", { recursive: true });

const { publicKey, privateKey } = generateKeyPairSync("ed25519");

writeFileSync("keys/public.pem", publicKey.export({ type: "spki", format: "pem" }));

writeFileSync(
  "keys/private.pem",
  privateKey.export({ type: "pkcs8", format: "pem" }),
  { mode: 0o600 }
);

console.log("✅ Keys written to keys/public.pem and keys/private.pem");
console.log("⚠️  Do NOT commit keys/private.pem");
