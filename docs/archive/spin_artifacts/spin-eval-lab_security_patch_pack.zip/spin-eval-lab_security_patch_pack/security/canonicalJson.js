export function canonicalStringify(value) {
  if (value === null) return "null";
  const t = typeof value;

  if (t === "boolean") return value ? "true" : "false";

  if (t === "number") {
    if (!Number.isFinite(value)) throw new Error("Non-finite number not allowed");
    return JSON.stringify(value);
  }

  if (t === "string") return JSON.stringify(value);

  if (Array.isArray(value)) {
    return "[" + value.map((v) => canonicalStringify(v)).join(",") + "]";
  }

  if (t === "object") {
    if (Object.getPrototypeOf(value) !== Object.prototype) {
      throw new Error("Only plain objects allowed");
    }
    const keys = Object.keys(value).sort();
    return (
      "{" +
      keys
        .map((k) => JSON.stringify(k) + ":" + canonicalStringify(value[k]))
        .join(",") +
      "}"
    );
  }

  throw new Error(`Unsupported type: ${t}`);
}
