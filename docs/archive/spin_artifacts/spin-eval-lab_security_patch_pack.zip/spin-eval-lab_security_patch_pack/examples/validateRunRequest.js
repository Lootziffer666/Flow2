import { isPlainObject, assertKeys, assertString, assertInt } from "../security/validate.js";

export function validateRunRequest(body) {
  if (!isPlainObject(body)) throw new Error("Body must be an object");
  assertKeys(body, ["flowId", "config"]);

  const flowId = assertString(body.flowId, {
    name: "flowId",
    max: 80,
    pattern: /^[a-zA-Z0-9._-]+$/,
  });

  const config = body.config;
  if (!isPlainObject(config)) throw new Error("config must be object");
  assertKeys(config, ["seed", "datasetId", "timeoutMs"]);

  const seed = assertInt(config.seed, { name: "seed", min: 0, max: 2 ** 31 - 1 });
  const datasetId = assertString(config.datasetId, {
    name: "datasetId",
    max: 80,
    pattern: /^[a-zA-Z0-9._-]+$/,
  });
  const timeoutMs = assertInt(config.timeoutMs, { name: "timeoutMs", min: 1000, max: 10 * 60 * 1000 });

  return { flowId, config: { seed, datasetId, timeoutMs } };
}
