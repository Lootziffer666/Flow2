import { sign as csign, verify as cverify, createPrivateKey, createPublicKey } from "node:crypto";

export function signBytes(dataBuf, privatePem) {
  const key = createPrivateKey(privatePem);
  return csign(null, dataBuf, key); // null = Ed25519
}

export function verifyBytes(dataBuf, sigBuf, publicPem) {
  const key = createPublicKey(publicPem);
  return cverify(null, dataBuf, key, sigBuf);
}
