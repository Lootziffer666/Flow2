import path from "node:path";
import { createReadStream, statSync } from "node:fs";

const MIME = new Map([
  [".html", "text/html; charset=utf-8"],
  [".js", "text/javascript; charset=utf-8"],
  [".css", "text/css; charset=utf-8"],
  [".json", "application/json; charset=utf-8"],
  [".png", "image/png"],
  [".jpg", "image/jpeg"],
  [".jpeg", "image/jpeg"],
  [".svg", "image/svg+xml"],
  [".ico", "image/x-icon"],
]);

export function serveStatic({ baseDir, indexFile = "index.html" }) {
  const base = path.resolve(baseDir);

  return function handle(req, res) {
    const url = new URL(req.url, "http://localhost");
    let rel = decodeURIComponent(url.pathname);
    if (rel === "/") rel = "/" + indexFile;

    // Prevent path traversal
    const target = path.resolve(base, "." + rel);
    if (!target.startsWith(base + path.sep) && target !== base) {
      res.writeHead(403);
      res.end("Forbidden");
      return true;
    }

    let st;
    try {
      st = statSync(target);
      if (!st.isFile()) throw new Error("not file");
    } catch {
      return false; // not handled
    }

    const ext = path.extname(target).toLowerCase();
    const ctype = MIME.get(ext) || "application/octet-stream";

    res.setHeader("Content-Type", ctype);
    // Basic cache policy: don't cache HTML; cache assets lightly unless you use hashed filenames.
    if (ext === ".html") res.setHeader("Cache-Control", "no-store");
    else res.setHeader("Cache-Control", "public, max-age=300");

    createReadStream(target).pipe(res);
    return true;
  };
}
