import path from "node:path";
import { readFile, readdir } from "node:fs/promises";
import { canonicalStringify } from "../security/canonicalJson.js";
import { sha256Hex } from "../security/hash.js";
import { verifyBytes } from "../security/sign.js";

function arg(name, def=null) {
  const idx = process.argv.indexOf(name);
  if (idx === -1) return def;
  return process.argv[idx + 1] ?? def;
}

async function walk(dir) {
  const out = [];
  const items = await readdir(dir, { withFileTypes: true });
  for (const it of items) {
    const p = path.join(dir, it.name);
    if (it.isDirectory()) out.push(...await walk(p));
    else out.push(p);
  }
  return out;
}

async function main() {
  const dir = arg("--dir", "./artifacts");
  const pubPath = arg("--pub", "./keys/public.pem");
  const publicPem = await readFile(pubPath, "utf8");

  const files = await walk(dir);
  const jsonFiles = files.filter(f => f.endsWith(".json") && !f.endsWith(".sig.json"));

  let okCount = 0;
  let failCount = 0;

  for (const jf of jsonFiles) {
    const sigPath = jf.replace(/\.json$/, ".sig.json");
    const shaPath = jf.replace(/\.json$/, ".sha256");

    try {
      const raw = await readFile(jf, "utf8");
      const obj = JSON.parse(raw);

      const canonical = canonicalStringify(obj);
      const dataBuf = Buffer.from(canonical, "utf8");
      const hash = sha256Hex(dataBuf);

      const sigMeta = JSON.parse(await readFile(sigPath, "utf8"));
      const sigBuf = Buffer.from(sigMeta.sig, "base64");

      const ok = verifyBytes(dataBuf, sigBuf, publicPem);
      if (!ok) throw new Error("Signature verification failed");

      if (sigMeta.hash && sigMeta.hash !== hash) throw new Error("Hash mismatch vs sig meta");

      // optional sha256 file check
      try {
        const sha = (await readFile(shaPath, "utf8")).trim();
        if (sha && sha !== hash) throw new Error("Hash mismatch vs .sha256");
      } catch {
        // sha missing is allowed; keep strict by enforcing presence if you want
      }

      okCount++;
    } catch (e) {
      failCount++;
      console.error("❌", jf, "-", e.message);
    }
  }

  console.log(`\nVerified: ${okCount} OK, ${failCount} FAIL`);
  if (failCount > 0) process.exit(1);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
